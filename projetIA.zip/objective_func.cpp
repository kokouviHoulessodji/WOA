#include "objective_func.h"

int objective_func::getDimension() const {
    return dimension;
}
